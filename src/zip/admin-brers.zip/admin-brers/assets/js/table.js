
$(document).ready(function () {
    $("#table_id").DataTable({
        lengthChange: false,
        dom: 'Bfrtip',
        buttons: {
            buttons: [
                {
                    extend: 'copyHtml5',
                    text: '<i class="fa fa-files-o"></i>',
                    titleAttr: 'Copy',
                    className: 'botao'
                },
                {
                    extend: 'excelHtml5',
                    text: '<i class="fa fa-file-excel-o"></i>',
                    titleAttr: 'Excel',
                    className: 'botao'
                },
                {
                    extend: 'csvHtml5',
                    text: '<i class="fa fa-file-text-o"></i>',
                    titleAttr: 'CSV',
                    className: 'botao'
                },
                {
                    extend: 'pdfHtml5',
                    text: '<i class="fa fa-file-pdf-o"></i>',
                    titleAttr: 'PDF',
                    className: 'botao'
                }
            ]
        }
    });
    table.buttons().container().appendTo('#tab_olt_wrapper .col-md-6:eq(0)');
});

$(document).ready(function () {
    $("#table_id_two").DataTable({
        lengthChange: false,
        dom: 'Bfrtip',
        buttons: {
            buttons: [
                {
                    extend: 'copyHtml5',
                    text: '<i class="fa fa-files-o"></i>',
                    titleAttr: 'Copy',
                    className: 'botao'
                },
                {
                    extend: 'excelHtml5',
                    text: '<i class="fa fa-file-excel-o"></i>',
                    titleAttr: 'Excel',
                    className: 'botao'
                },
                {
                    extend: 'csvHtml5',
                    text: '<i class="fa fa-file-text-o"></i>',
                    titleAttr: 'CSV',
                    className: 'botao'
                },
                {
                    extend: 'pdfHtml5',
                    text: '<i class="fa fa-file-pdf-o"></i>',
                    titleAttr: 'PDF',
                    className: 'botao'
                }
            ]
        }
    });
    table.buttons().container().appendTo('#tab_olt_wrapper .col-md-6:eq(0)');
});


$(document).ready(function () {
    $("#table_id_three").DataTable({
        lengthChange: false,
        dom: 'Bfrtip',
        buttons: {
            buttons: [
                {
                    extend: 'copyHtml5',
                    text: '<i class="fa fa-files-o"></i>',
                    titleAttr: 'Copy',
                    className: 'botao'
                },
                {
                    extend: 'excelHtml5',
                    text: '<i class="fa fa-file-excel-o"></i>',
                    titleAttr: 'Excel',
                    className: 'botao'
                },
                {
                    extend: 'csvHtml5',
                    text: '<i class="fa fa-file-text-o"></i>',
                    titleAttr: 'CSV',
                    className: 'botao'
                },
                {
                    extend: 'pdfHtml5',
                    text: '<i class="fa fa-file-pdf-o"></i>',
                    titleAttr: 'PDF',
                    className: 'botao'
                }
            ]
        }
    });
    table.buttons().container().appendTo('#tab_olt_wrapper .col-md-6:eq(0)');
});

$(document).ready(function () {
    $("#table_id_four").DataTable({
        lengthChange: false,
        dom: 'Bfrtip',
        buttons: {
            buttons: [
                {
                    extend: 'copyHtml5',
                    text: '<i class="fa fa-files-o"></i>',
                    titleAttr: 'Copy',
                    className: 'botao'
                },
                {
                    extend: 'excelHtml5',
                    text: '<i class="fa fa-file-excel-o"></i>',
                    titleAttr: 'Excel',
                    className: 'botao'
                },
                {
                    extend: 'csvHtml5',
                    text: '<i class="fa fa-file-text-o"></i>',
                    titleAttr: 'CSV',
                    className: 'botao'
                },
                {
                    extend: 'pdfHtml5',
                    text: '<i class="fa fa-file-pdf-o"></i>',
                    titleAttr: 'PDF',
                    className: 'botao'
                }
            ]
        }
    });
    table.buttons().container().appendTo('#tab_olt_wrapper .col-md-6:eq(0)');
});

$(document).ready(function () {
    $("#table_id_five").DataTable({
        lengthChange: false,
        dom: 'Bfrtip',
        buttons: {
            buttons: [
                {
                    extend: 'copyHtml5',
                    text: '<i class="fa fa-files-o"></i>',
                    titleAttr: 'Copy',
                    className: 'botao'
                },
                {
                    extend: 'excelHtml5',
                    text: '<i class="fa fa-file-excel-o"></i>',
                    titleAttr: 'Excel',
                    className: 'botao'
                },
                {
                    extend: 'csvHtml5',
                    text: '<i class="fa fa-file-text-o"></i>',
                    titleAttr: 'CSV',
                    className: 'botao'
                },
                {
                    extend: 'pdfHtml5',
                    text: '<i class="fa fa-file-pdf-o"></i>',
                    titleAttr: 'PDF',
                    className: 'botao'
                }
            ]
        }
    });
    table.buttons().container().appendTo('#tab_olt_wrapper .col-md-6:eq(0)');
});
